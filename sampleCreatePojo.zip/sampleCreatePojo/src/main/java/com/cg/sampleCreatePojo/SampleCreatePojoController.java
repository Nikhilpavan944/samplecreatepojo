package com.cg.sampleCreatePojo;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.Executors;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.sampleCreatePojo.Service.StreamGobbler;

@RestController
public class SampleCreatePojoController {


		
		@RequestMapping(value = "/sampleswaggerapi")
	public SampleCreatePojoApplication printYAML(@RequestBody SwaggerSchemaRequest request)
			throws IOException, InterruptedException {

		SwaggerSchemaRequest swaggerschemarequest = new SwaggerSchemaRequest();
		boolean isWindows = System.getProperty("os.name").toLowerCase().startsWith("windows");
		// String homeDirectory = System.getProperty("user.home");
		String homeDirectory = System.getProperty(swaggerschemarequest.getXmlpath());

		Process process;
		if (isWindows) {
			process = Runtime.getRuntime().exec(String.format("cmd.exe /c dir %s" + homeDirectory));
		} else {
			process = Runtime.getRuntime().exec(String.format("sh -c ls %s", homeDirectory));
		}
		StreamGobbler streamGobbler = new StreamGobbler(process.getInputStream(), System.out::println);
		Executors.newSingleThreadExecutor().submit(streamGobbler);
		int exitCode = process.waitFor();
		assert exitCode == 0;
		return null;

		/*
		 * try { // We are running "dir" and "ping" command on cmd
		 * Runtime.getRuntime().exec("cmd /c start cmd.exe /K \"dir && ping localhost\""
		 * ); } catch (Exception e) {
		 * System.out.println("HEY Buddy ! U r Doing Something Wrong ");
		 * e.printStackTrace(); }
		 * 
		 * 
		 * }
		 */
	}
		@RequestMapping(value = "/generate", method = RequestMethod.POST)
		public String generatePojo(@RequestBody SwaggerSchemaRequest req) throws IOException {
			Runtime rt = Runtime.getRuntime();
			Process proc = rt.exec("xjc -d "+req.getXmlpath()+" -p "+"com.cg.sampleCreatePojo.model"+" Employee.xsd");
return "done";
		}
}
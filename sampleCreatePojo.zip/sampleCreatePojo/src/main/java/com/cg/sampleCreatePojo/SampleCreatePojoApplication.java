package com.cg.sampleCreatePojo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
public class SampleCreatePojoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SampleCreatePojoApplication.class, args);
	}
}
